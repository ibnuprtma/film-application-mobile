-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 13 Jan 2020 pada 02.07
-- Versi Server: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_film`
--
CREATE DATABASE IF NOT EXISTS `db_film` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_film`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `film`
--

DROP TABLE IF EXISTS `film`;
CREATE TABLE `film` (
  `id` int(11) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `durasi` int(11) NOT NULL,
  `images` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `film`
--

INSERT INTO `film` (`id`, `judul`, `genre`, `tahun`, `durasi`, `images`) VALUES
(1, 'Avengers End Game', 'Fantasy, Sci-Fi', '2019', 182, 'avengers-endgame.jpg'),
(2, 'Frozen II', 'Drama, Fantasy', '2019', 103, 'frozen-2.jpg'),
(3, 'Joker', 'Drama, Thriller', '2019', 122, 'joker.jpg'),
(4, 'John Wick: Chapter 3', 'Thriller, Mystery', '2019', 130, 'john-wick-3.jpg'),
(5, 'Doraemon', 'gak tau', '2020', 100, 'default.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `film`
--
ALTER TABLE `film`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
