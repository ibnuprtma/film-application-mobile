<?php

$conn = mysqli_connect("localhost", "root", "password", "db_film");

if(mysqli_connect_errno()){
    echo 'Koneksi Gagal : ' . mysqli_connect_error();
}