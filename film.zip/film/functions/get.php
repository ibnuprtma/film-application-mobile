<?php
include '../config/connection.php';

$query = "select * from film";
$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0){
    $response = array();
    $response['status'] = "success";
    $response['rows'] = mysqli_num_rows($result);
    $response['film'] = array();
    while ($row = mysqli_fetch_array($result)) {
        $film['id'] = $row['id'];
        $film['judul'] = $row['judul'];
        $film['genre'] = $row['genre'];
        $film['tahun'] = $row['tahun'];
        $film['durasi'] = $row['durasi'];
        $film['images'] = $row['images'];
        array_push($response['film'], $film);
    }
    
    echo json_encode($response);
}